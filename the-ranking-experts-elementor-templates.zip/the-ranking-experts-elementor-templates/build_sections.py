import json
import uuid
import os

OUTPUT_DIR = r"C:\Users\Marketing Mindz 360\.gemini\antigravity\scratch\the-ranking-experts-elementor-templates"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def gen_id():
    return uuid.uuid4().hex[:7]

def wrap_section(title, elements, settings=None):
    if settings is None:
        settings = {
            "background_background": "classic",
            "background_color": "#07090E",
            "padding": {
                "unit": "px",
                "top": "90",
                "right": "20",
                "bottom": "90",
                "left": "20",
                "isLinked": False
            }
        }
    
    section_id = gen_id()
    col_id = gen_id()
    
    return {
        "version": "0.4",
        "title": title,
        "type": "section",
        "content": [
            {
                "id": section_id,
                "elType": "section",
                "isInner": False,
                "settings": settings,
                "elements": [
                    {
                        "id": col_id,
                        "elType": "column",
                        "isInner": False,
                        "settings": {
                            "_column_size": 100,
                            "_inline_size": None
                        },
                        "elements": elements
                    }
                ]
            }
        ],
        "page_settings": {}
    }

def make_html_widget(html_content, extra_settings=None):
    s = {
        "html": html_content
    }
    if extra_settings:
        s.update(extra_settings)
    return {
        "id": gen_id(),
        "elType": "widget",
        "isInner": False,
        "widgetType": "html",
        "settings": s
    }

# -------------------------------------------------------------
# 1. HEADER SECTION
# -------------------------------------------------------------
header_html = """
<div class="tre-header-wrapper" style="width: 100%; max-width: 1240px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; padding: 18px 28px; background: rgba(13, 19, 31, 0.75); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,0.4);">
  <!-- Brand Logo -->
  <a href="#home" style="display: flex; align-items: center; gap: 12px; text-decoration: none;">
    <div style="width: 42px; height: 42px; border-radius: 10px; background: linear-gradient(135deg, #4F46E5, #06B6D4); display: flex; align-items: center; justify-content: center; box-shadow: 0 0 20px rgba(79, 70, 229, 0.5);">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 3v18h18"/>
        <path d="m19 9-5 5-4-4-3 3"/>
        <circle cx="19" cy="9" r="2" fill="#FFFFFF"/>
      </svg>
    </div>
    <div style="display: flex; flex-direction: column;">
      <span style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: 20px; font-weight: 800; color: #FFFFFF; letter-spacing: -0.02em; line-height: 1.1;">THE RANKING<span style="color: #06B6D4;">.</span></span>
      <span style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: 11px; font-weight: 700; color: #818CF8; letter-spacing: 0.15em; text-transform: uppercase;">EXPERTS</span>
    </div>
  </a>

  <!-- Navigation Menu -->
  <nav class="tre-desktop-nav" style="display: flex; align-items: center; gap: 32px;">
    <a href="#home" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #FFFFFF; text-decoration: none; transition: color 0.2s;">Home</a>
    <a href="#services" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 500; color: #94A3B8; text-decoration: none; transition: color 0.2s;">Services</a>
    <a href="#about" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 500; color: #94A3B8; text-decoration: none; transition: color 0.2s;">About</a>
    <a href="#work" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 500; color: #94A3B8; text-decoration: none; transition: color 0.2s;">Case Studies</a>
    <a href="#process" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 500; color: #94A3B8; text-decoration: none; transition: color 0.2s;">Process</a>
    <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 500; color: #94A3B8; text-decoration: none; transition: color 0.2s;">Contact</a>
  </nav>

  <!-- CTA Button & Actions -->
  <div style="display: flex; align-items: center; gap: 16px;">
    <a href="#contact" class="tre-header-btn" style="display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; background: linear-gradient(135deg, #4F46E5 0%, #6366F1 100%); color: #FFFFFF; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; border-radius: 10px; text-decoration: none; border: 1px solid rgba(255,255,255,0.15); box-shadow: 0 4px 14px rgba(79, 70, 229, 0.35); transition: all 0.3s ease;">
      <span>Book Strategy Call</span>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M5 12h14m-7-7 7 7-7 7"/>
      </svg>
    </a>
  </div>
</div>
"""

header_template = wrap_section(
    title="Header - The Ranking Experts",
    elements=[make_html_widget(header_html)],
    settings={
        "background_background": "classic",
        "background_color": "#07090E",
        "padding": {
            "unit": "px",
            "top": "25",
            "right": "20",
            "bottom": "25",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "01-header.json"), "w", encoding="utf-8") as f:
    json.dump(header_template, f, indent=2)

# -------------------------------------------------------------
# 2. HERO SECTION
# -------------------------------------------------------------
hero_html = """
<div style="width: 100%; max-width: 1200px; margin: 0 auto; text-align: center; position: relative;">
  <!-- Glow backdrop decoration -->
  <div style="position: absolute; top: -100px; left: 50%; transform: translateX(-50%); width: 600px; height: 350px; background: radial-gradient(circle, rgba(99, 102, 241, 0.25) 0%, rgba(6, 182, 212, 0.08) 50%, transparent 80%); filter: blur(60px); pointer-events: none; z-index: 0;"></div>

  <div style="position: relative; z-index: 1;">
    <!-- Pill Badge -->
    <div style="display: inline-flex; align-items: center; gap: 10px; padding: 8px 20px; background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 9999px; margin-bottom: 28px; backdrop-filter: blur(10px);">
      <span style="width: 8px; height: 8px; background: #10B981; border-radius: 50%; display: inline-block; box-shadow: 0 0 10px #10B981;"></span>
      <span style="font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #C7D2FE; letter-spacing: 0.04em;">PREMIER SEARCH DOMINANCE & GROWTH ARCHITECTURE</span>
    </div>

    <!-- Main Headline -->
    <h1 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(38px, 6vw, 68px); font-weight: 800; line-height: 1.08; letter-spacing: -0.03em; color: #FFFFFF; margin: 0 auto 24px auto; max-width: 1050px;">
      Engineering Unrivaled Search Rankings & <span style="background: linear-gradient(135deg, #818CF8 0%, #38BDF8 50%, #34D399 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Predictable Scale.</span>
    </h1>

    <!-- Short Intro -->
    <p style="font-family: Inter, sans-serif; font-size: clamp(16px, 1.8vw, 20px); font-weight: 400; line-height: 1.6; color: #94A3B8; max-width: 780px; margin: 0 auto 40px auto;">
      We bridge algorithmic rigor, high-intent performance PPC, and conversion-first UI/UX engineering. Transforming ambitious brands from competitive obscurity into undisputed category dominators.
    </p>

    <!-- CTAs -->
    <div style="display: flex; align-items: center; justify-content: center; gap: 16px; flex-wrap: wrap; margin-bottom: 60px;">
      <a href="#contact" style="display: inline-flex; align-items: center; gap: 10px; padding: 18px 36px; background: linear-gradient(135deg, #4F46E5 0%, #6366F1 50%, #06B6D4 100%); color: #FFFFFF; font-family: Inter, sans-serif; font-size: 16px; font-weight: 600; border-radius: 12px; text-decoration: none; box-shadow: 0 10px 30px rgba(79, 70, 229, 0.45); border: 1px solid rgba(255, 255, 255, 0.2); transition: all 0.3s ease;">
        <span>Get a Free Quote & Audit</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M5 12h14m-7-7 7 7-7 7"/>
        </svg>
      </a>

      <a href="#work" style="display: inline-flex; align-items: center; gap: 10px; padding: 18px 32px; background: rgba(255, 255, 255, 0.04); color: #F1F5F9; font-family: Inter, sans-serif; font-size: 16px; font-weight: 600; border-radius: 12px; text-decoration: none; border: 1px solid rgba(255, 255, 255, 0.12); backdrop-filter: blur(10px); transition: all 0.3s ease;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="5 3 19 12 5 21 5 3"/>
        </svg>
        <span>View Case Studies</span>
      </a>
    </div>

    <!-- Metrics Strip -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; max-width: 1050px; margin: 0 auto; padding: 28px; background: rgba(13, 19, 31, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; backdrop-filter: blur(16px);">
      <div style="text-align: center; border-right: 1px solid rgba(255,255,255,0.06); padding: 10px;">
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 38px; font-weight: 800; color: #FFFFFF; letter-spacing: -0.02em;">$54M+</div>
        <div style="font-family: Inter, sans-serif; font-size: 13px; font-weight: 500; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 4px;">Verified Client Revenue</div>
      </div>
      <div style="text-align: center; border-right: 1px solid rgba(255,255,255,0.06); padding: 10px;">
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 38px; font-weight: 800; color: #38BDF8; letter-spacing: -0.02em;">380%</div>
        <div style="font-family: Inter, sans-serif; font-size: 13px; font-weight: 500; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 4px;">Average Organic Lift</div>
      </div>
      <div style="text-align: center; border-right: 1px solid rgba(255,255,255,0.06); padding: 10px;">
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 38px; font-weight: 800; color: #34D399; letter-spacing: -0.02em;">99.4%</div>
        <div style="font-family: Inter, sans-serif; font-size: 13px; font-weight: 500; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 4px;">Client Retention Rate</div>
      </div>
      <div style="text-align: center; padding: 10px;">
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 38px; font-weight: 800; color: #A78BFA; letter-spacing: -0.02em;">12+ Yrs</div>
        <div style="font-family: Inter, sans-serif; font-size: 13px; font-weight: 500; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 4px;">Search Expertise</div>
      </div>
    </div>
  </div>
</div>
"""

hero_template = wrap_section(
    title="Hero Section - The Ranking Experts",
    elements=[make_html_widget(hero_html)],
    settings={
        "background_background": "classic",
        "background_color": "#07090E",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "80",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "02-hero.json"), "w", encoding="utf-8") as f:
    json.dump(hero_template, f, indent=2)

# -------------------------------------------------------------
# 3. ABOUT US SECTION
# -------------------------------------------------------------
about_html = """
<div id="about" style="width: 100%; max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 50px; align-items: center;">
  <!-- Left Side: Editorial Content -->
  <div>
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 9999px; margin-bottom: 20px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #38BDF8; letter-spacing: 0.1em; text-transform: uppercase;">ABOUT THE RANKING EXPERTS</span>
    </div>

    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4vw, 46px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 24px 0;">
      A Digital Marketing Agency Built for <span style="background: linear-gradient(135deg, #818CF8, #38BDF8); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Radical Clarity & Compounded ROI.</span>
    </h2>

    <p style="font-family: Inter, sans-serif; font-size: 16px; font-weight: 400; line-height: 1.7; color: #94A3B8; margin-bottom: 24px;">
      Most agencies drown you in vanity impressions and boilerplate reports. At <strong style="color: #F8FAFC;">The Ranking Experts</strong>, we operate as an embedded growth engineering squad. We merge high-level creative strategy with scientific algorithmic optimization to capture high-ticket market share.
    </p>

    <!-- Key Advantage Pillars -->
    <div style="display: flex; flex-direction: column; gap: 16px; margin-bottom: 32px;">
      <div style="display: flex; align-items: flex-start; gap: 14px;">
        <div style="width: 28px; height: 28px; border-radius: 8px; background: rgba(99, 102, 241, 0.2); border: 1px solid #6366F1; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#818CF8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div>
          <h4 style="font-family: Inter, sans-serif; font-size: 16px; font-weight: 700; color: #FFFFFF; margin: 0 0 4px 0;">Zero Vanity Metrics</h4>
          <p style="font-family: Inter, sans-serif; font-size: 14px; color: #94A3B8; margin: 0; line-height: 1.5;">We measure success strictly in pipeline revenue, qualified pipeline SQLs, and verifiable customer acquisition cost (CAC).</p>
        </div>
      </div>

      <div style="display: flex; align-items: flex-start; gap: 14px;">
        <div style="width: 28px; height: 28px; border-radius: 8px; background: rgba(6, 182, 212, 0.2); border: 1px solid #06B6D4; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div>
          <h4 style="font-family: Inter, sans-serif; font-size: 16px; font-weight: 700; color: #FFFFFF; margin: 0 0 4px 0;">Algorithmic Precision & Deep Technical Auditing</h4>
          <p style="font-family: Inter, sans-serif; font-size: 14px; color: #94A3B8; margin: 0; line-height: 1.5;">Reverse-engineering core search engine updates and behavioral heuristics to insulate your business against volatility.</p>
        </div>
      </div>

      <div style="display: flex; align-items: flex-start; gap: 14px;">
        <div style="width: 28px; height: 28px; border-radius: 8px; background: rgba(16, 185, 129, 0.2); border: 1px solid #10B981; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#34D399" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div>
          <h4 style="font-family: Inter, sans-serif; font-size: 16px; font-weight: 700; color: #FFFFFF; margin: 0 0 4px 0;">Senior Engineers & Strategists Only</h4>
          <p style="font-family: Inter, sans-serif; font-size: 14px; color: #94A3B8; margin: 0; line-height: 1.5;">No junior account coordinators learning on your dime. You get direct access to battle-tested operators.</p>
        </div>
      </div>
    </div>

    <a href="#services" style="display: inline-flex; align-items: center; gap: 8px; font-family: Inter, sans-serif; font-size: 15px; font-weight: 600; color: #38BDF8; text-decoration: none; border-bottom: 1px solid #38BDF8; padding-bottom: 2px;">
      Explore our capabilities and service matrix →
    </a>
  </div>

  <!-- Right Side: High-Tech Glassmorphic Agency Card -->
  <div style="position: relative;">
    <div style="background: linear-gradient(135deg, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.9) 100%); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 24px; padding: 36px; box-shadow: 0 30px 60px rgba(0, 0, 0, 0.5); backdrop-filter: blur(20px);">
      <!-- Card header -->
      <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255, 255, 255, 0.08); padding-bottom: 20px; margin-bottom: 24px;">
        <div>
          <div style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 600; color: #38BDF8; letter-spacing: 0.1em; text-transform: uppercase;">Growth Architecture</div>
          <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF;">Live Pipeline Performance</div>
        </div>
        <div style="display: flex; align-items: center; gap: 6px; padding: 4px 12px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 20px; color: #34D399; font-size: 12px; font-weight: 600;">
          <span style="width: 6px; height: 6px; background: #34D399; border-radius: 50%;"></span> Active Sync
        </div>
      </div>

      <!-- Growth Chart Graphic / Metrics Mockup -->
      <div style="background: rgba(11, 15, 25, 0.6); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 16px; padding: 20px; margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-end; height: 110px; gap: 12px; padding: 10px 10px 0 10px;">
          <div style="flex: 1; background: rgba(99, 102, 241, 0.3); border-radius: 6px 6px 0 0; height: 35%;"></div>
          <div style="flex: 1; background: rgba(99, 102, 241, 0.45); border-radius: 6px 6px 0 0; height: 50%;"></div>
          <div style="flex: 1; background: rgba(99, 102, 241, 0.6); border-radius: 6px 6px 0 0; height: 65%;"></div>
          <div style="flex: 1; background: rgba(6, 182, 212, 0.7); border-radius: 6px 6px 0 0; height: 80%;"></div>
          <div style="flex: 1; background: linear-gradient(180deg, #38BDF8 0%, #6366F1 100%); border-radius: 6px 6px 0 0; height: 100%;"></div>
        </div>
        <div style="display: flex; justify-content: space-between; margin-top: 10px; font-size: 11px; color: #64748B; font-family: Inter, sans-serif; font-weight: 500;">
          <span>Q1 Discovery</span>
          <span>Q2 Ramp</span>
          <span>Q3 Traction</span>
          <span>Q4 Dominance</span>
        </div>
      </div>

      <!-- Verified Badges -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div style="padding: 14px; background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 12px;">
          <div style="font-size: 22px; font-weight: 800; color: #FFFFFF; font-family: 'Plus Jakarta Sans', sans-serif;">+420%</div>
          <div style="font-size: 12px; color: #94A3B8; font-family: Inter, sans-serif;">Avg Keyword Elevation</div>
        </div>
        <div style="padding: 14px; background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 12px;">
          <div style="font-size: 22px; font-weight: 800; color: #34D399; font-family: 'Plus Jakarta Sans', sans-serif;">-38%</div>
          <div style="font-size: 12px; color: #94A3B8; font-family: Inter, sans-serif;">Blended CAC Reduction</div>
        </div>
      </div>
    </div>
  </div>
</div>
"""

about_template = wrap_section(
    title="About Us - The Ranking Experts",
    elements=[make_html_widget(about_html)],
    settings={
        "background_background": "classic",
        "background_color": "#0B0F19",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "03-about-us.json"), "w", encoding="utf-8") as f:
    json.dump(about_template, f, indent=2)

# -------------------------------------------------------------
# 4. OUR SERVICES SECTION (6 CARDS)
# -------------------------------------------------------------
services_html = """
<div id="services" style="width: 100%; max-width: 1200px; margin: 0 auto;">
  <!-- Section Heading -->
  <div style="text-align: center; max-width: 750px; margin: 0 auto 60px auto;">
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; background: rgba(99, 102, 241, 0.12); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 9999px; margin-bottom: 16px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #818CF8; letter-spacing: 0.1em; text-transform: uppercase;">SPECIALIZED EXPERTISE</span>
    </div>
    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4.5vw, 48px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 16px 0;">
      Precision-Built Services For <span style="background: linear-gradient(135deg, #818CF8 0%, #38BDF8 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Aggressive Market Scaling</span>
    </h2>
    <p style="font-family: Inter, sans-serif; font-size: 16px; color: #94A3B8; line-height: 1.6; margin: 0;">
      Six integrated core competencies, executed by senior practitioners to generate compounding competitive advantage.
    </p>
  </div>

  <!-- 6 Service Cards Grid -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 28px;">
    
    <!-- Card 1: Enterprise SEO -->
    <div style="background: linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%), #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; padding: 36px 30px; transition: all 0.35s ease; position: relative;">
      <div style="width: 52px; height: 52px; border-radius: 14px; background: rgba(79, 70, 229, 0.15); border: 1px solid rgba(79, 70, 229, 0.4); display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#818CF8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/>
          <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          <path d="m11 8 3 3-3 3"/>
        </svg>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #818CF8; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;">Organic Dominance</div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 14px 0;">Enterprise SEO & Algorithmic Scaling</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin-bottom: 20px;">
        Full technical architecture audits, programmatic internal linking, semantic entity graph optimization, and Tier-1 digital PR that catapults you to #1.
      </p>
      <ul style="list-style: none; padding: 0; margin: 0 0 24px 0; display: flex; flex-direction: column; gap: 10px;">
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Deep Core Web Vitals Optimization</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Semantic Search & Knowledge Graph SEO</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> High-Authority Backlink Acquisition</li>
      </ul>
      <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #38BDF8; text-decoration: none;">Get Strategy Blueprint →</a>
    </div>

    <!-- Card 2: Performance PPC -->
    <div style="background: linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%), #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; padding: 36px 30px; transition: all 0.35s ease; position: relative;">
      <div style="width: 52px; height: 52px; border-radius: 14px; background: rgba(6, 182, 212, 0.15); border: 1px solid rgba(6, 182, 212, 0.4); display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
        </svg>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #38BDF8; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;">Paid Media & Acquisition</div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 14px 0;">Performance PPC & High-ROAS Media</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin-bottom: 20px;">
        Precision ad deployment across Google Search, YouTube, Meta, and LinkedIn with algorithmic bidding models engineered for ruthless capital efficiency.
      </p>
      <ul style="list-style: none; padding: 0; margin: 0 0 24px 0; display: flex; flex-direction: column; gap: 10px;">
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Multi-Touch Attribution & Offline Tracking</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> High-Converting Ad Creative Testing</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Automated Negative Keyword Scrims</li>
      </ul>
      <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #38BDF8; text-decoration: none;">Get Strategy Blueprint →</a>
    </div>

    <!-- Card 3: CRO -->
    <div style="background: linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%), #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; padding: 36px 30px; transition: all 0.35s ease; position: relative;">
      <div style="width: 52px; height: 52px; border-radius: 14px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#34D399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
          <polyline points="17 6 23 6 23 12"/>
        </svg>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #34D399; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;">Funnel Science</div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 14px 0;">Conversion Rate Optimization (CRO)</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin-bottom: 20px;">
        Double your revenue without spending an extra dollar on traffic. We run scientific A/B split tests, scroll heatmaps, and psychological funnel overhauls.
      </p>
      <ul style="list-style: none; padding: 0; margin: 0 0 24px 0; display: flex; flex-direction: column; gap: 10px;">
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Quantitative Drop-Off Diagnostics</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> High-Impact Landing Page Wireframing</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Checkout Friction Removal & Micro-copy</li>
      </ul>
      <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #38BDF8; text-decoration: none;">Get Strategy Blueprint →</a>
    </div>

    <!-- Card 4: Web & UI/UX -->
    <div style="background: linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%), #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; padding: 36px 30px; transition: all 0.35s ease; position: relative;">
      <div style="width: 52px; height: 52px; border-radius: 14px; background: rgba(168, 85, 247, 0.15); border: 1px solid rgba(168, 85, 247, 0.4); display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#C084FC" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect width="18" height="18" x="3" y="3" rx="2"/>
          <path d="M3 9h18"/>
          <path d="M9 21V9"/>
        </svg>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #C084FC; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;">Digital Architecture</div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 14px 0;">Modern Web & UI/UX Development</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin-bottom: 20px;">
        Ultra-fast, responsive web interfaces engineered for modern search crawlers and uncompromising user engagement. Built to turn casual clicks into signed deals.
      </p>
      <ul style="list-style: none; padding: 0; margin: 0 0 24px 0; display: flex; flex-direction: column; gap: 10px;">
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Sub-Second Loading Speeds & Clean Code</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Mobile-First Responsive Micro-interactions</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Native Elementor & WordPress Fluidity</li>
      </ul>
      <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #38BDF8; text-decoration: none;">Get Strategy Blueprint →</a>
    </div>

    <!-- Card 5: Content Marketing -->
    <div style="background: linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%), #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; padding: 36px 30px; transition: all 0.35s ease; position: relative;">
      <div style="width: 52px; height: 52px; border-radius: 14px; background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4); display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FBBF24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/>
          <line x1="16" y1="17" x2="8" y2="17"/>
          <polyline points="10 9 9 9 8 9"/>
        </svg>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #FBBF24; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;">Authority Velocity</div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 14px 0;">Content Strategy & High-Ticket Copy</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin-bottom: 20px;">
        Topical cluster architecture, thought-leadership whitepapers, and persuasive direct-response copy that builds unbreakable domain authority.
      </p>
      <ul style="list-style: none; padding: 0; margin: 0 0 24px 0; display: flex; flex-direction: column; gap: 10px;">
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> High-Intent BOFU Keyword Topic Hubs</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Executive Ghostwriting & E-E-A-T Anchoring</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Video & Multi-Channel Syndication</li>
      </ul>
      <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #38BDF8; text-decoration: none;">Get Strategy Blueprint →</a>
    </div>

    <!-- Card 6: Marketing Automation -->
    <div style="background: linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%), #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; padding: 36px 30px; transition: all 0.35s ease; position: relative;">
      <div style="width: 52px; height: 52px; border-radius: 14px; background: rgba(236, 72, 153, 0.15); border: 1px solid rgba(236, 72, 153, 0.4); display: flex; align-items: center; justify-content: center; margin-bottom: 24px;">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#F472B6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="3"/>
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
        </svg>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #F472B6; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 8px;">Lifecycle Retention</div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 14px 0;">Marketing Automation & Lifecycle CRM</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin-bottom: 20px;">
        Behavioral email nurture workflows, automated lead scoring, and automated pipeline integration in HubSpot & Salesforce to monetize every lead.
      </p>
      <ul style="list-style: none; padding: 0; margin: 0 0 24px 0; display: flex; flex-direction: column; gap: 10px;">
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Dynamic Segmentation & Churn Prevention</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Lead Scoring & Instant Sales Rep Alerts</li>
        <li style="font-size: 13px; color: #CBD5E1; display: flex; align-items: center; gap: 8px;"><span style="color: #34D399;">✔</span> Klaviyo, ActiveCampaign & HubSpot Mastery</li>
      </ul>
      <a href="#contact" style="font-family: Inter, sans-serif; font-size: 14px; font-weight: 600; color: #38BDF8; text-decoration: none;">Get Strategy Blueprint →</a>
    </div>

  </div>
</div>
"""

services_template = wrap_section(
    title="Our Services - The Ranking Experts",
    elements=[make_html_widget(services_html)],
    settings={
        "background_background": "classic",
        "background_color": "#07090E",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "04-our-services.json"), "w", encoding="utf-8") as f:
    json.dump(services_template, f, indent=2)

# -------------------------------------------------------------
# 5. WHY CHOOSE US SECTION (Quality, Creativity, Strategy, Results)
# -------------------------------------------------------------
why_choose_us_html = """
<div id="why-us" style="width: 100%; max-width: 1200px; margin: 0 auto;">
  <!-- Header -->
  <div style="text-align: center; max-width: 800px; margin: 0 auto 60px auto;">
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 9999px; margin-bottom: 16px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #38BDF8; letter-spacing: 0.1em; text-transform: uppercase;">THE UNFAIR ADVANTAGE</span>
    </div>
    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4.5vw, 48px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 16px 0;">
      Why High-Growth Companies Switch To <span style="background: linear-gradient(135deg, #38BDF8 0%, #34D399 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">The Ranking Experts</span>
    </h2>
    <p style="font-family: Inter, sans-serif; font-size: 16px; color: #94A3B8; line-height: 1.6; margin: 0;">
      We built our agency around four unshakeable pillars designed to eliminate waste and guarantee compounded market dominance.
    </p>
  </div>

  <!-- 4 Pillars Grid -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(270px, 1fr)); gap: 24px; margin-bottom: 50px;">
    
    <!-- Pillar 1: Quality -->
    <div style="background: rgba(13, 19, 31, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 18px; padding: 32px 26px; border-top: 3px solid #6366F1;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
        <span style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 32px; font-weight: 800; color: rgba(99, 102, 241, 0.4);">01</span>
        <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(99, 102, 241, 0.15); display: flex; align-items: center; justify-content: center;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#818CF8" stroke-width="2.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        </div>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Obsessive Quality</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin: 0;">
        No outsourced cut-rate work or cookie-cutter templates. Every line of code, technical schema, and campaign asset meets Fortune 500 standards.
      </p>
    </div>

    <!-- Pillar 2: Creativity -->
    <div style="background: rgba(13, 19, 31, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 18px; padding: 32px 26px; border-top: 3px solid #06B6D4;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
        <span style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 32px; font-weight: 800; color: rgba(6, 182, 212, 0.4);">02</span>
        <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(6, 182, 212, 0.15); display: flex; align-items: center; justify-content: center;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" stroke-width="2.5"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>
        </div>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Breakthrough Creativity</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin: 0;">
        In a noisy AI-generated web, only authentic, provocative storytelling commands attention. We craft bold hooks that stop users mid-scroll.
      </p>
    </div>

    <!-- Pillar 3: Strategy -->
    <div style="background: rgba(13, 19, 31, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 18px; padding: 32px 26px; border-top: 3px solid #10B981;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
        <span style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 32px; font-weight: 800; color: rgba(16, 185, 129, 0.4);">03</span>
        <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(16, 185, 129, 0.15); display: flex; align-items: center; justify-content: center;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#34D399" stroke-width="2.5"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="m9 8 6 4-6 4Z"/></svg>
        </div>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Algorithmic Strategy</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin: 0;">
        We don't guess. We map competitor vulnerabilities, identify high-intent unexploited search queries, and systematically conquer market territory.
      </p>
    </div>

    <!-- Pillar 4: Results -->
    <div style="background: rgba(13, 19, 31, 0.7); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 18px; padding: 32px 26px; border-top: 3px solid #F59E0B;">
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
        <span style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 32px; font-weight: 800; color: rgba(245, 158, 11, 0.4);">04</span>
        <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(245, 158, 11, 0.15); display: flex; align-items: center; justify-content: center;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FBBF24" stroke-width="2.5"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        </div>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Predictable Results</h3>
      <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.65; color: #94A3B8; margin: 0;">
        Real-time pipeline dashboards, verified revenue attribution, and contracted service level milestones. If we don't perform, we don't sleep.
      </p>
    </div>

  </div>

  <!-- Agency Comparison Box -->
  <div style="background: linear-gradient(135deg, rgba(255,255,255,0.02), rgba(255,255,255,0.005)), #0B0F19; border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; padding: 36px;">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; align-items: center;">
      <div>
        <h4 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 22px; font-weight: 700; color: #FFFFFF; margin: 0 0 8px 0;">The "Other Agencies" Problem</h4>
        <p style="font-family: Inter, sans-serif; font-size: 14px; color: #94A3B8; line-height: 1.6; margin: 0 0 16px 0;">
          Junior staff managing 40 accounts each, canned monthly PDFs with zero pipeline context, and endless excuses about algorithm updates.
        </p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <span style="font-size: 12px; padding: 4px 10px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #F87171; border-radius: 6px;">✕ Vanity Traffic Only</span>
          <span style="font-size: 12px; padding: 4px 10px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #F87171; border-radius: 6px;">✕ 12-Month Lock-ins</span>
          <span style="font-size: 12px; padding: 4px 10px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #F87171; border-radius: 6px;">✕ Zero Accountability</span>
        </div>
      </div>

      <div style="background: rgba(99, 102, 241, 0.08); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 14px; padding: 24px;">
        <h4 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #818CF8; margin: 0 0 8px 0;">The Ranking Experts Standard</h4>
        <p style="font-family: Inter, sans-serif; font-size: 14px; color: #CBD5E1; line-height: 1.6; margin: 0 0 14px 0;">
          Direct senior architect access, transparent live SQL dashboards, performance-linked milestones, and rapid agile execution.
        </p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <span style="font-size: 12px; padding: 4px 10px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #34D399; border-radius: 6px;">✓ Verified Revenue Tracking</span>
          <span style="font-size: 12px; padding: 4px 10px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #34D399; border-radius: 6px;">✓ Dedicated Senior Squad</span>
          <span style="font-size: 12px; padding: 4px 10px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #34D399; border-radius: 6px;">✓ Agile Sprints</span>
        </div>
      </div>
    </div>
  </div>
</div>
"""

why_choose_us_template = wrap_section(
    title="Why Choose Us - The Ranking Experts",
    elements=[make_html_widget(why_choose_us_html)],
    settings={
        "background_background": "classic",
        "background_color": "#0B0F19",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "05-why-choose-us.json"), "w", encoding="utf-8") as f:
    json.dump(why_choose_us_template, f, indent=2)

# -------------------------------------------------------------
# 6. OUR WORK / PORTFOLIO SECTION
# -------------------------------------------------------------
our_work_html = """
<div id="work" style="width: 100%; max-width: 1200px; margin: 0 auto;">
  <!-- Section Heading -->
  <div style="text-align: center; max-width: 750px; margin: 0 auto 60px auto;">
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 9999px; margin-bottom: 16px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #34D399; letter-spacing: 0.1em; text-transform: uppercase;">PROVEN TRACK RECORD</span>
    </div>
    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4.5vw, 48px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 16px 0;">
      Case Studies That Speak in <span style="background: linear-gradient(135deg, #34D399 0%, #38BDF8 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Revenue & Dominance</span>
    </h2>
    <p style="font-family: Inter, sans-serif; font-size: 16px; color: #94A3B8; line-height: 1.6; margin: 0;">
      Explore real transformations where our integrated SEO, PPC, and CRO methodologies broke growth ceilings.
    </p>
  </div>

  <!-- Portfolio Grid: 4 Projects -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 30px;">
    
    <!-- Project 1 -->
    <div style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; overflow: hidden; transition: all 0.35s ease;">
      <div style="height: 190px; background: linear-gradient(135deg, #1E1B4B 0%, #0F172A 100%); padding: 24px; display: flex; flex-direction: column; justify-content: space-between; position: relative;">
        <span style="align-self: flex-start; padding: 4px 12px; background: rgba(99, 102, 241, 0.25); border: 1px solid rgba(99, 102, 241, 0.4); border-radius: 20px; font-size: 11px; font-weight: 700; color: #818CF8; text-transform: uppercase;">Enterprise B2B SaaS</span>
        <div>
          <div style="font-size: 32px; font-weight: 800; color: #34D399; font-family: 'Plus Jakarta Sans', sans-serif;">+480%</div>
          <div style="font-size: 13px; color: #CBD5E1; font-weight: 600;">Organic Pipeline ARR in 9 Months</div>
        </div>
      </div>
      <div style="padding: 26px;">
        <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Apex Global Data Cloud</h3>
        <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.6; color: #94A3B8; margin: 0 0 20px 0;">
          Overhauled programmatic SEO architecture, built 45 authoritative BOFU comparison pages, and ranked #1 for high-ticket cloud security keywords.
        </p>
        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255, 255, 255, 0.06); padding-top: 16px;">
          <span style="font-size: 13px; color: #64748B;">Services: SEO + Content Hubs</span>
          <a href="#contact" style="font-size: 13px; font-weight: 600; color: #38BDF8; text-decoration: none;">Read Teardown →</a>
        </div>
      </div>
    </div>

    <!-- Project 2 -->
    <div style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; overflow: hidden; transition: all 0.35s ease;">
      <div style="height: 190px; background: linear-gradient(135deg, #064E3B 0%, #0F172A 100%); padding: 24px; display: flex; flex-direction: column; justify-content: space-between; position: relative;">
        <span style="align-self: flex-start; padding: 4px 12px; background: rgba(16, 185, 129, 0.25); border: 1px solid rgba(16, 185, 129, 0.4); border-radius: 20px; font-size: 11px; font-weight: 700; color: #34D399; text-transform: uppercase;">D2C Luxury E-Commerce</span>
        <div>
          <div style="font-size: 32px; font-weight: 800; color: #38BDF8; font-family: 'Plus Jakarta Sans', sans-serif;">6.4x ROAS</div>
          <div style="font-size: 13px; color: #CBD5E1; font-weight: 600;">Scaling from \$80k/mo to \$650k/mo</div>
        </div>
      </div>
      <div style="padding: 26px;">
        <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Velour Home Goods</h3>
        <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.6; color: #94A3B8; margin: 0 0 20px 0;">
          Restructured Google Performance Max campaigns, engineered custom high-converting product advertorials, and reduced blended CAC by 42%.
        </p>
        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255, 255, 255, 0.06); padding-top: 16px;">
          <span style="font-size: 13px; color: #64748B;">Services: Google Ads + CRO</span>
          <a href="#contact" style="font-size: 13px; font-weight: 600; color: #38BDF8; text-decoration: none;">Read Teardown →</a>
        </div>
      </div>
    </div>

    <!-- Project 3 -->
    <div style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; overflow: hidden; transition: all 0.35s ease;">
      <div style="height: 190px; background: linear-gradient(135deg, #3B0764 0%, #0F172A 100%); padding: 24px; display: flex; flex-direction: column; justify-content: space-between; position: relative;">
        <span style="align-self: flex-start; padding: 4px 12px; background: rgba(168, 85, 247, 0.25); border: 1px solid rgba(168, 85, 247, 0.4); border-radius: 20px; font-size: 11px; font-weight: 700; color: #C084FC; text-transform: uppercase;">FinTech & Payments</span>
        <div>
          <div style="font-size: 32px; font-weight: 800; color: #A855F7; font-family: 'Plus Jakarta Sans', sans-serif;">+182% CVR</div>
          <div style="font-size: 13px; color: #CBD5E1; font-weight: 600;">Signup Funnel Redesign & Optimization</div>
        </div>
      </div>
      <div style="padding: 26px;">
        <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Stratos Capital Infrastructure</h3>
        <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.6; color: #94A3B8; margin: 0 0 20px 0;">
          A complete web redesign and multi-step onboarding overhaul. Reduced onboarding drop-off from 68% down to 22% within 60 days.
        </p>
        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255, 255, 255, 0.06); padding-top: 16px;">
          <span style="font-size: 13px; color: #64748B;">Services: Web UI/UX + CRO</span>
          <a href="#contact" style="font-size: 13px; font-weight: 600; color: #38BDF8; text-decoration: none;">Read Teardown →</a>
        </div>
      </div>
    </div>

    <!-- Project 4 -->
    <div style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 20px; overflow: hidden; transition: all 0.35s ease;">
      <div style="height: 190px; background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%); padding: 24px; display: flex; flex-direction: column; justify-content: space-between; position: relative;">
        <span style="align-self: flex-start; padding: 4px 12px; background: rgba(56, 189, 248, 0.25); border: 1px solid rgba(56, 189, 248, 0.4); border-radius: 20px; font-size: 11px; font-weight: 700; color: #38BDF8; text-transform: uppercase;">National Healthcare & Telehealth</span>
        <div>
          <div style="font-size: 32px; font-weight: 800; color: #FBBF24; font-family: 'Plus Jakarta Sans', sans-serif;">#1 Rank</div>
          <div style="font-size: 13px; color: #CBD5E1; font-weight: 600;">For 140+ Competitive National Keywords</div>
        </div>
      </div>
      <div style="padding: 26px;">
        <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">VitalPulse Telemedicine</h3>
        <p style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.6; color: #94A3B8; margin: 0 0 20px 0;">
          E-E-A-T medical content auditing, Schema.org health markup, and authoritative medical institution link outreach yielding 3.2M organic monthly sessions.
        </p>
        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255, 255, 255, 0.06); padding-top: 16px;">
          <span style="font-size: 13px; color: #64748B;">Services: Organic SEO + Digital PR</span>
          <a href="#contact" style="font-size: 13px; font-weight: 600; color: #38BDF8; text-decoration: none;">Read Teardown →</a>
        </div>
      </div>
    </div>

  </div>
</div>
"""

our_work_template = wrap_section(
    title="Our Work - The Ranking Experts",
    elements=[make_html_widget(our_work_html)],
    settings={
        "background_background": "classic",
        "background_color": "#07090E",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "06-our-work.json"), "w", encoding="utf-8") as f:
    json.dump(our_work_template, f, indent=2)

# -------------------------------------------------------------
# 7. OUR PROCESS SECTION (Discover -> Plan -> Create -> Launch -> Optimize)
# -------------------------------------------------------------
our_process_html = """
<div id="process" style="width: 100%; max-width: 1200px; margin: 0 auto;">
  <!-- Section Heading -->
  <div style="text-align: center; max-width: 750px; margin: 0 auto 60px auto;">
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; background: rgba(99, 102, 241, 0.12); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 9999px; margin-bottom: 16px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #818CF8; letter-spacing: 0.1em; text-transform: uppercase;">HOW WE DELIVER</span>
    </div>
    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4.5vw, 48px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 16px 0;">
      A 5-Stage Scientific Engine: <br><span style="background: linear-gradient(135deg, #818CF8, #38BDF8); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">From Audit to Category Dominance</span>
    </h2>
    <p style="font-family: Inter, sans-serif; font-size: 16px; color: #94A3B8; line-height: 1.6; margin: 0;">
      No guesswork. No random marketing tactics. We follow an iterative 5-step engineering sprint that compounds returns.
    </p>
  </div>

  <!-- 5-Step Process Timeline Grid -->
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 20px; position: relative;">
    
    <!-- Step 1: Discover -->
    <div style="background: rgba(13, 19, 31, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 26px 20px; position: relative;">
      <div style="font-size: 12px; font-weight: 800; color: #818CF8; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
        <span>STAGE 01</span>
        <span style="width: 8px; height: 8px; background: #818CF8; border-radius: 50%;"></span>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Discover</h3>
      <p style="font-family: Inter, sans-serif; font-size: 13px; line-height: 1.6; color: #94A3B8; margin: 0;">
        Exhaustive forensic audit of your technical infrastructure, market competitors, keyword gaps, and drop-off funnels.
      </p>
    </div>

    <!-- Step 2: Plan -->
    <div style="background: rgba(13, 19, 31, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 26px 20px; position: relative;">
      <div style="font-size: 12px; font-weight: 800; color: #38BDF8; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
        <span>STAGE 02</span>
        <span style="width: 8px; height: 8px; background: #38BDF8; border-radius: 50%;"></span>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Plan</h3>
      <p style="font-family: Inter, sans-serif; font-size: 13px; line-height: 1.6; color: #94A3B8; margin: 0;">
        Constructing the master growth roadmap, defining KPI benchmarks, allocating paid media budgets, and mapping content silos.
      </p>
    </div>

    <!-- Step 3: Create -->
    <div style="background: rgba(13, 19, 31, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 26px 20px; position: relative;">
      <div style="font-size: 12px; font-weight: 800; color: #34D399; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
        <span>STAGE 03</span>
        <span style="width: 8px; height: 8px; background: #34D399; border-radius: 50%;"></span>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Create</h3>
      <p style="font-family: Inter, sans-serif; font-size: 13px; line-height: 1.6; color: #94A3B8; margin: 0;">
        Engineering high-converting landing pages, crafting authoritative SEO content, and producing high-engagement ad creatives.
      </p>
    </div>

    <!-- Step 4: Launch -->
    <div style="background: rgba(13, 19, 31, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 26px 20px; position: relative;">
      <div style="font-size: 12px; font-weight: 800; color: #FBBF24; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
        <span>STAGE 04</span>
        <span style="width: 8px; height: 8px; background: #FBBF24; border-radius: 50%;"></span>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Launch</h3>
      <p style="font-family: Inter, sans-serif; font-size: 13px; line-height: 1.6; color: #94A3B8; margin: 0;">
        Coordinated campaign rollouts across search engines, paid networks, and conversion tracking pixels with live attribution hooks.
      </p>
    </div>

    <!-- Step 5: Optimize -->
    <div style="background: rgba(13, 19, 31, 0.6); border: 1px solid rgba(99, 102, 241, 0.4); border-radius: 16px; padding: 26px 20px; position: relative; box-shadow: 0 10px 25px rgba(99, 102, 241, 0.15);">
      <div style="font-size: 12px; font-weight: 800; color: #C084FC; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
        <span>STAGE 05</span>
        <span style="width: 8px; height: 8px; background: #C084FC; border-radius: 50%;"></span>
      </div>
      <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 20px; font-weight: 700; color: #FFFFFF; margin: 0 0 10px 0;">Optimize</h3>
      <p style="font-family: Inter, sans-serif; font-size: 13px; line-height: 1.6; color: #94A3B8; margin: 0;">
        Bi-weekly A/B multivariate tests, search query bid re-balancing, link authority scaling, and aggressive CAC deflation.
      </p>
    </div>

  </div>
</div>
"""

our_process_template = wrap_section(
    title="Our Process - The Ranking Experts",
    elements=[make_html_widget(our_process_html)],
    settings={
        "background_background": "classic",
        "background_color": "#0B0F19",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "07-our-process.json"), "w", encoding="utf-8") as f:
    json.dump(our_process_template, f, indent=2)

# -------------------------------------------------------------
# 8. FAQS SECTION
# -------------------------------------------------------------
faqs_html = """
<div id="faqs" style="width: 100%; max-width: 900px; margin: 0 auto;">
  <!-- Section Heading -->
  <div style="text-align: center; margin-bottom: 50px;">
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; background: rgba(99, 102, 241, 0.12); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 9999px; margin-bottom: 16px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #818CF8; letter-spacing: 0.1em; text-transform: uppercase;">QUESTIONS & ANSWERS</span>
    </div>
    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4vw, 44px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 16px 0;">
      Frequently Asked Questions
    </h2>
    <p style="font-family: Inter, sans-serif; font-size: 16px; color: #94A3B8; line-height: 1.6; margin: 0;">
      Straightforward answers regarding our digital marketing, organic search engineering, and performance services.
    </p>
  </div>

  <!-- Modern Accordion List -->
  <div style="display: flex; flex-direction: column; gap: 16px;">
    
    <!-- FAQ 1 -->
    <details style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 14px; padding: 22px 26px; cursor: pointer;" open>
      <summary style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; list-style: none; display: flex; justify-content: space-between; align-items: center;">
        <span>How quickly can we expect measurable ROI from your campaigns?</span>
        <span style="color: #38BDF8; font-size: 20px; font-weight: 300;">+</span>
      </summary>
      <div style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.7; color: #94A3B8; margin-top: 14px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 14px;">
        For paid media (PPC & Paid Social) and CRO, traction is visible within 14 to 30 days as high-intent campaigns launch and immediate conversions occur. For Enterprise SEO, meaningful rankings acceleration and compounded organic traffic typically mature between months 3 to 6 as search crawlers index technical overhauls and authority backlinks register.
      </div>
    </details>

    <!-- FAQ 2 -->
    <details style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 14px; padding: 22px 26px; cursor: pointer;">
      <summary style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; list-style: none; display: flex; justify-content: space-between; align-items: center;">
        <span>How does The Ranking Experts differ from conventional agencies?</span>
        <span style="color: #38BDF8; font-size: 20px; font-weight: 300;">+</span>
      </summary>
      <div style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.7; color: #94A3B8; margin-top: 14px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 14px;">
        Traditional agencies rely on junior account managers and vanity metrics (impressions, clicks) to obscure lack of pipeline impact. We operate as an elite engineering team: every client is led by a senior growth architect with 8+ years experience, with 100% transparent live attribution dashboards directly connected to your actual revenue.
      </div>
    </details>

    <!-- FAQ 3 -->
    <details style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 14px; padding: 22px 26px; cursor: pointer;">
      <summary style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; list-style: none; display: flex; justify-content: space-between; align-items: center;">
        <span>Do we need to sign a restrictive long-term lock-in contract?</span>
        <span style="color: #38BDF8; font-size: 20px; font-weight: 300;">+</span>
      </summary>
      <div style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.7; color: #94A3B8; margin-top: 14px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 14px;">
        No. While search optimization compounds over time and we recommend a minimum 3 to 6-month horizon for maximum compounding return, we earn our retention every single month. We do not believe in trapping clients in predatory 12-month lock-ins.
      </div>
    </details>

    <!-- FAQ 4 -->
    <details style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 14px; padding: 22px 26px; cursor: pointer;">
      <summary style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; list-style: none; display: flex; justify-content: space-between; align-items: center;">
        <span>What level of team involvement is required from our side?</span>
        <span style="color: #38BDF8; font-size: 20px; font-weight: 300;">+</span>
      </summary>
      <div style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.7; color: #94A3B8; margin-top: 14px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 14px;">
        During the first two weeks (Discovery & Audit), we request 2-3 hours of stakeholder interviews and access to Google Analytics, Search Console, and ad accounts. After kickoff, our squad handles 95% of execution autonomously, providing bi-weekly async video teardowns and monthly strategy alignments.
      </div>
    </details>

    <!-- FAQ 5 -->
    <details style="background: #0E1422; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 14px; padding: 22px 26px; cursor: pointer;">
      <summary style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; list-style: none; display: flex; justify-content: space-between; align-items: center;">
        <span>How do you handle Google algorithmic updates and search shifts?</span>
        <span style="color: #38BDF8; font-size: 20px; font-weight: 300;">+</span>
      </summary>
      <div style="font-family: Inter, sans-serif; font-size: 14px; line-height: 1.7; color: #94A3B8; margin-top: 14px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 14px;">
        We build on timeless algorithmic principles: semantic relevance, real entity authority, sub-second Core Web Vitals, and authentic editorial value. Our clients consistently gain rankings during core updates because our foundation is engineered to satisfy the search engine's ultimate goal: delivering the most authoritative answer.
      </div>
    </details>

  </div>
</div>
"""

faqs_template = wrap_section(
    title="FAQs - The Ranking Experts",
    elements=[make_html_widget(faqs_html)],
    settings={
        "background_background": "classic",
        "background_color": "#07090E",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "08-faqs.json"), "w", encoding="utf-8") as f:
    json.dump(faqs_template, f, indent=2)

# -------------------------------------------------------------
# 9. CONTACT US SECTION
# -------------------------------------------------------------
contact_html = """
<div id="contact" style="width: 100%; max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 50px; align-items: start;">
  <!-- Left Side: Contact Information & Direct Channels -->
  <div>
    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 9999px; margin-bottom: 20px;">
      <span style="font-family: Inter, sans-serif; font-size: 12px; font-weight: 700; color: #38BDF8; letter-spacing: 0.1em; text-transform: uppercase;">START YOUR ASCENT</span>
    </div>

    <h2 style="font-family: 'Plus Jakarta Sans', Inter, sans-serif; font-size: clamp(32px, 4vw, 46px); font-weight: 800; line-height: 1.15; letter-spacing: -0.02em; color: #FFFFFF; margin: 0 0 20px 0;">
      Claim Your Free <br><span style="background: linear-gradient(135deg, #818CF8, #38BDF8); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Competitive Search Audit</span>
    </h2>

    <p style="font-family: Inter, sans-serif; font-size: 16px; font-weight: 400; line-height: 1.7; color: #94A3B8; margin-bottom: 36px;">
      Fill out the inquiry form or reach out directly. Within 24 hours, our senior strategists will dissect your top 3 competitors and deliver an actionable revenue blueprint.
    </p>

    <!-- Direct Contact Cards -->
    <div style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 36px;">
      
      <div style="display: flex; align-items: center; gap: 16px;">
        <div style="width: 46px; height: 46px; border-radius: 12px; background: rgba(99, 102, 241, 0.15); border: 1px solid rgba(99, 102, 241, 0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#818CF8" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        </div>
        <div>
          <div style="font-size: 12px; font-weight: 600; color: #64748B; text-transform: uppercase;">Direct Line / WhatsApp</div>
          <a href="tel:+18005557265" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; text-decoration: none;">+1 (800) 555-RANK</a>
        </div>
      </div>

      <div style="display: flex; align-items: center; gap: 16px;">
        <div style="width: 46px; height: 46px; border-radius: 12px; background: rgba(6, 182, 212, 0.15); border: 1px solid rgba(6, 182, 212, 0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
        </div>
        <div>
          <div style="font-size: 12px; font-weight: 600; color: #64748B; text-transform: uppercase;">Direct VIP Inquiries</div>
          <a href="mailto:growth@therankingexperts.com" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF; text-decoration: none;">growth@therankingexperts.com</a>
        </div>
      </div>

      <div style="display: flex; align-items: center; gap: 16px;">
        <div style="width: 46px; height: 46px; border-radius: 12px; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#34D399" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
        </div>
        <div>
          <div style="font-size: 12px; font-weight: 600; color: #64748B; text-transform: uppercase;">Global Operations Hub</div>
          <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 700; color: #FFFFFF;">San Francisco, CA & London, UK</div>
        </div>
      </div>

    </div>

    <!-- Social Links Pills -->
    <div>
      <div style="font-size: 13px; font-weight: 600; color: #94A3B8; margin-bottom: 12px;">Connect with our executive team:</div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <a href="https://linkedin.com" target="_blank" style="padding: 8px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: #CBD5E1; font-size: 13px; font-weight: 600; text-decoration: none;">LinkedIn</a>
        <a href="https://x.com" target="_blank" style="padding: 8px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: #CBD5E1; font-size: 13px; font-weight: 600; text-decoration: none;">Twitter / X</a>
        <a href="https://youtube.com" target="_blank" style="padding: 8px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: #CBD5E1; font-size: 13px; font-weight: 600; text-decoration: none;">YouTube</a>
        <a href="https://instagram.com" target="_blank" style="padding: 8px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: #CBD5E1; font-size: 13px; font-weight: 600; text-decoration: none;">Instagram</a>
      </div>
    </div>
  </div>

  <!-- Right Side: High-End Contact & Audit Form -->
  <div style="background: linear-gradient(145deg, rgba(30, 41, 59, 0.7), rgba(15, 23, 42, 0.9)), #0B0F19; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 24px; padding: 40px; box-shadow: 0 30px 60px rgba(0, 0, 0, 0.5); backdrop-filter: blur(20px);">
    <h3 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 24px; font-weight: 700; color: #FFFFFF; margin: 0 0 6px 0;">Request A Growth Proposal</h3>
    <p style="font-family: Inter, sans-serif; font-size: 14px; color: #94A3B8; margin: 0 0 28px 0;">No sales reps. Strictly strategic analysis from a partner.</p>

    <form onsubmit="event.preventDefault(); alert('Inquiry received! The Ranking Experts team will review your domain within 24 hours.');" style="display: flex; flex-direction: column; gap: 18px;">
      
      <!-- Full Name -->
      <div>
        <label style="display: block; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #CBD5E1; margin-bottom: 6px;">Your Name *</label>
        <input type="text" required placeholder="Alexander Vance" style="width: 100%; padding: 14px 16px; background: rgba(11, 15, 25, 0.8); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #FFFFFF; font-family: Inter, sans-serif; font-size: 14px; outline: none; box-sizing: border-box;">
      </div>

      <!-- Business Email & Phone -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
        <div>
          <label style="display: block; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #CBD5E1; margin-bottom: 6px;">Work Email *</label>
          <input type="email" required placeholder="alex@company.com" style="width: 100%; padding: 14px 16px; background: rgba(11, 15, 25, 0.8); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #FFFFFF; font-family: Inter, sans-serif; font-size: 14px; outline: none; box-sizing: border-box;">
        </div>
        <div>
          <label style="display: block; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #CBD5E1; margin-bottom: 6px;">Website URL *</label>
          <input type="text" required placeholder="https://company.com" style="width: 100%; padding: 14px 16px; background: rgba(11, 15, 25, 0.8); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #FFFFFF; font-family: Inter, sans-serif; font-size: 14px; outline: none; box-sizing: border-box;">
        </div>
      </div>

      <!-- Service Interested In -->
      <div>
        <label style="display: block; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #CBD5E1; margin-bottom: 6px;">Primary Service Focus</label>
        <select style="width: 100%; padding: 14px 16px; background: #0B0F19; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #FFFFFF; font-family: Inter, sans-serif; font-size: 14px; outline: none; box-sizing: border-box;">
          <option value="seo">Enterprise Search Engine Optimization (SEO)</option>
          <option value="ppc">Performance PPC & Paid Advertising</option>
          <option value="cro">Conversion Rate Optimization (CRO)</option>
          <option value="web">Web & UI/UX Development</option>
          <option value="content">Content Strategy & Authority Copy</option>
          <option value="full">Full Omnichannel Growth Retainer</option>
        </select>
      </div>

      <!-- Monthly Budget -->
      <div>
        <label style="display: block; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #CBD5E1; margin-bottom: 6px;">Estimated Monthly Growth Budget</label>
        <select style="width: 100%; padding: 14px 16px; background: #0B0F19; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #FFFFFF; font-family: Inter, sans-serif; font-size: 14px; outline: none; box-sizing: border-box;">
          <option value="5k-10k">$5,000 - $10,000 / month</option>
          <option value="10k-25k" selected>$10,000 - $25,000 / month</option>
          <option value="25k-50k">$25,000 - $50,000 / month</option>
          <option value="50k+">$50,000+ / month (Enterprise)</option>
        </select>
      </div>

      <!-- Message -->
      <div>
        <label style="display: block; font-family: Inter, sans-serif; font-size: 13px; font-weight: 600; color: #CBD5E1; margin-bottom: 6px;">Tell us about your current bottlenecks</label>
        <textarea rows="3" placeholder="Current monthly traffic, revenue goals, and top competitors..." style="width: 100%; padding: 14px 16px; background: rgba(11, 15, 25, 0.8); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #FFFFFF; font-family: Inter, sans-serif; font-size: 14px; outline: none; box-sizing: border-box; resize: vertical;"></textarea>
      </div>

      <!-- Submit Button -->
      <button type="submit" style="width: 100%; padding: 16px; background: linear-gradient(135deg, #4F46E5 0%, #6366F1 50%, #06B6D4 100%); color: #FFFFFF; font-family: Inter, sans-serif; font-size: 15px; font-weight: 700; border: none; border-radius: 12px; cursor: pointer; box-shadow: 0 10px 25px rgba(79, 70, 229, 0.4); transition: all 0.3s ease; margin-top: 6px;">
        Claim Free Strategic Audit →
      </button>

      <div style="text-align: center; font-size: 12px; color: #64748B; margin-top: 4px;">
        🔒 100% Confidential. NDA guaranteed. Zero spam tolerance.
      </div>

    </form>
  </div>
</div>
"""

contact_template = wrap_section(
    title="Contact Us - The Ranking Experts",
    elements=[make_html_widget(contact_html)],
    settings={
        "background_background": "classic",
        "background_color": "#07090E",
        "padding": {
            "unit": "px",
            "top": "90",
            "right": "20",
            "bottom": "90",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "09-contact-us.json"), "w", encoding="utf-8") as f:
    json.dump(contact_template, f, indent=2)

# -------------------------------------------------------------
# 10. FOOTER SECTION
# -------------------------------------------------------------
footer_html = """
<div id="footer" style="width: 100%; max-width: 1200px; margin: 0 auto; color: #94A3B8; font-family: Inter, sans-serif;">
  <!-- Top Grid -->
  <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1.5fr; gap: 40px; padding-bottom: 60px; border-bottom: 1px solid rgba(255, 255, 255, 0.08);">
    
    <!-- Col 1: Brand Info -->
    <div>
      <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
        <div style="width: 38px; height: 38px; border-radius: 10px; background: linear-gradient(135deg, #4F46E5, #06B6D4); display: flex; align-items: center; justify-content: center;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.5"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
        </div>
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 19px; font-weight: 800; color: #FFFFFF;">THE RANKING<span style="color: #06B6D4;">.</span> EXPERTS</div>
      </div>
      <p style="font-size: 14px; line-height: 1.7; color: #94A3B8; max-width: 320px; margin-bottom: 24px;">
        An elite digital marketing and algorithmic growth architecture agency. Transforming ambitious organizations into dominant market leaders through scientific organic search and capital-efficient paid media.
      </p>
      <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #34D399; font-weight: 600;">
        <span style="width: 8px; height: 8px; background: #34D399; border-radius: 50%; box-shadow: 0 0 8px #34D399;"></span>
        <span>Accepting Select New Clients for Q1 / Q2</span>
      </div>
    </div>

    <!-- Col 2: The Six Services -->
    <div>
      <h4 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 15px; font-weight: 700; color: #FFFFFF; text-transform: uppercase; letter-spacing: 0.08em; margin: 0 0 18px 0;">Our Services</h4>
      <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 12px; font-size: 14px;">
        <li><a href="#services" style="color: #94A3B8; text-decoration: none; transition: color 0.2s;">Enterprise SEO</a></li>
        <li><a href="#services" style="color: #94A3B8; text-decoration: none; transition: color 0.2s;">Performance PPC</a></li>
        <li><a href="#services" style="color: #94A3B8; text-decoration: none; transition: color 0.2s;">Conversion Rate (CRO)</a></li>
        <li><a href="#services" style="color: #94A3B8; text-decoration: none; transition: color 0.2s;">Web & UI/UX Engineering</a></li>
        <li><a href="#services" style="color: #94A3B8; text-decoration: none; transition: color 0.2s;">Content & Authority Copy</a></li>
        <li><a href="#services" style="color: #94A3B8; text-decoration: none; transition: color 0.2s;">Marketing Automation</a></li>
      </ul>
    </div>

    <!-- Col 3: Navigation -->
    <div>
      <h4 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 15px; font-weight: 700; color: #FFFFFF; text-transform: uppercase; letter-spacing: 0.08em; margin: 0 0 18px 0;">Company</h4>
      <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 12px; font-size: 14px;">
        <li><a href="#about" style="color: #94A3B8; text-decoration: none;">About Us</a></li>
        <li><a href="#work" style="color: #94A3B8; text-decoration: none;">Case Studies</a></li>
        <li><a href="#why-us" style="color: #94A3B8; text-decoration: none;">Why Choose Us</a></li>
        <li><a href="#process" style="color: #94A3B8; text-decoration: none;">Our 5-Step Process</a></li>
        <li><a href="#faqs" style="color: #94A3B8; text-decoration: none;">FAQs</a></li>
        <li><a href="#contact" style="color: #94A3B8; text-decoration: none;">Contact Us</a></li>
      </ul>
    </div>

    <!-- Col 4: Newsletter & Direct Updates -->
    <div>
      <h4 style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 15px; font-weight: 700; color: #FFFFFF; text-transform: uppercase; letter-spacing: 0.08em; margin: 0 0 14px 0;">The Ranking Dispatch</h4>
      <p style="font-size: 13px; color: #94A3B8; line-height: 1.6; margin-bottom: 16px;">
        Join 14,000+ CMOs and founders receiving our weekly deep-dives on Google algorithm shifts and paid conversion science.
      </p>
      <form onsubmit="event.preventDefault(); alert('Subscribed to The Ranking Dispatch!');" style="display: flex; gap: 8px;">
        <input type="email" placeholder="Your executive email" required style="flex: 1; padding: 12px 14px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); border-radius: 8px; color: #FFFFFF; font-size: 13px; outline: none;">
        <button type="submit" style="padding: 12px 18px; background: #6366F1; border: none; border-radius: 8px; color: #FFFFFF; font-weight: 600; font-size: 13px; cursor: pointer;">Join</button>
      </form>
    </div>

  </div>

  <!-- Bottom Legal & Copyright Bar -->
  <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 30px; font-size: 13px; color: #64748B; flex-wrap: wrap; gap: 16px;">
    <div>
      © 2026 The Ranking Experts Inc. All Rights Reserved. Engineered for Search Dominance.
    </div>
    <div style="display: flex; gap: 24px;">
      <a href="#privacy" style="color: #64748B; text-decoration: none;">Privacy Policy</a>
      <a href="#terms" style="color: #64748B; text-decoration: none;">Terms of Service</a>
      <a href="#security" style="color: #64748B; text-decoration: none;">Security & Compliance</a>
    </div>
  </div>
</div>
"""

footer_template = wrap_section(
    title="Footer - The Ranking Experts",
    elements=[make_html_widget(footer_html)],
    settings={
        "background_background": "classic",
        "background_color": "#05070B",
        "padding": {
            "unit": "px",
            "top": "80",
            "right": "20",
            "bottom": "40",
            "left": "20",
            "isLinked": False
        }
    }
)

with open(os.path.join(OUTPUT_DIR, "10-footer.json"), "w", encoding="utf-8") as f:
    json.dump(footer_template, f, indent=2)

# -------------------------------------------------------------
# 11. COMPLETE FULL PAGE TEMPLATE (All Sections Combined)
# -------------------------------------------------------------
all_sections_content = [
    header_template["content"][0],
    hero_template["content"][0],
    about_template["content"][0],
    services_template["content"][0],
    why_choose_us_template["content"][0],
    our_work_template["content"][0],
    our_process_template["content"][0],
    faqs_template["content"][0],
    contact_template["content"][0],
    footer_template["content"][0]
]

full_page_template = {
    "version": "0.4",
    "title": "The Ranking Experts - Complete Landing Page",
    "type": "page",
    "content": all_sections_content,
    "page_settings": {
        "template": "elementor_canvas"
    }
}

with open(os.path.join(OUTPUT_DIR, "11-the-ranking-experts-full-page.json"), "w", encoding="utf-8") as f:
    json.dump(full_page_template, f, indent=2)

print("Successfully generated all 10 section templates + 1 complete full page template!")
