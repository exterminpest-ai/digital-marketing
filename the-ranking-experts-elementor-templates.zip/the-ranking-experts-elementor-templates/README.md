# The Ranking Experts — Premium Elementor Template Kit

Designed with a high-end, 10+ year senior developer aesthetic (Vercel / Linear / Dark-Obsidian tech agency style), this template kit gives **The Ranking Experts** a luxury, conversion-engineered digital marketing presence.

---

## 📁 Included Section-Wise JSON Files

| File Name | Section | Description |
| :--- | :--- | :--- |
| `01-header.json` | **Header** | Glassmorphic floating navigation bar, brand logo, menu links, and "Book Strategy Call" CTA. |
| `02-hero.json` | **Hero Section** | High-impact headline, glowing live status badge, value proposition, Dual CTAs, and verified ROI KPI metrics bar. |
| `03-about-us.json` | **About Us** | Agency positioning, 3 unfair advantage pillars, and interactive glassmorphic live performance dashboard mockup. |
| `04-our-services.json` | **Our Services** | 6 complete service cards: Enterprise SEO, Performance PPC, CRO, Web Development, Content Strategy, and Marketing Automation. |
| `05-why-choose-us.json` | **Why Choose Us** | The 4 core pillars (Quality, Creativity, Strategy, Results) + "Traditional Agencies vs The Ranking Experts" comparison box. |
| `06-our-work.json` | **Our Work / Portfolio**| 4 high-ROI client case studies (SaaS ARR, E-Commerce ROAS, FinTech CVR, National Telehealth SEO) with breakdown metrics. |
| `07-our-process.json` | **Our Process** | 5-stage interactive sprint roadmap: **Discover → Plan → Create → Launch → Optimize**. |
| `08-faqs.json` | **FAQs** | High-converting interactive accordion answering ROI timelines, contract models, algorithm updates, and team access. |
| `09-contact-us.json` | **Contact Us** | High-ticket conversion layout: Direct phone, VIP email, office locations, social badges, and comprehensive audit proposal form. |
| `10-footer.json` | **Footer** | Agency summary, newsletter subscription ("The Ranking Dispatch"), all 6 services linked, navigation, and legal links. |
| `11-the-ranking-experts-full-page.json` | **Master Page** | Complete all-in-one template containing all 10 sections linked together in perfect sequence. |
| `preview.html` | **Instant Live Preview** | Open this directly in any browser (Chrome, Edge, Safari) to see the full live design immediately without installing WordPress first. |

---

## 🚀 How to Import into WordPress Elementor

### Method 1: Import via WordPress Admin (Recommended)
1. In your WordPress admin dashboard, navigate to **Templates** → **Saved Templates**.
2. Click the **Import Templates** button at the top of the page.
3. Click **Choose File** and select any of the `.json` files (e.g., `01-header.json` or `11-the-ranking-experts-full-page.json`).
4. Click **Import Now**.
5. The template is now saved in your library and ready to insert into any page!

### Method 2: Insert Directly into an Elementor Page
1. Create or edit a page with Elementor.
2. Click the **Folder icon** ("Add Template") in the Elementor canvas.
3. In the modal that opens, click the **My Templates** tab.
4. Click the small **Upload icon** (up-arrow in a circle) in the top right.
5. Drag and drop any `.json` file from this folder.
6. Once uploaded, click **Insert** to drop the section directly onto your canvas.

---

## 🎨 Recommended Global Theme Settings

For optimal visual harmony:
- **Page Layout**: Set Page Template to **Elementor Canvas** (for a pure seamless look) or **Elementor Full Width**.
- **Background Color**: `#07090E` (Obsidian Dark) or `#0B0F19`.
- **Primary Font**: `Plus Jakarta Sans` or `Space Grotesk` (Headings: 700 / 800 weight).
- **Secondary Font**: `Inter` (Body: 400 / 500 / 600 weight).
- **Primary Accent**: Electric Indigo (`#4F46E5` / `#6366F1`).
- **Secondary Accent**: Cyber Cyan (`#06B6D4` / `#38BDF8`).
- **Growth Emerald**: (`#10B981` / `#34D399`).

---

## ✏️ How to Edit Content
Every heading, description, number, icon, and button is fully editable inside Elementor. Simply click on the element to change copy, update links to your own URLs, or connect your preferred WordPress form plugin (e.g. Elementor Pro Form, WPForms, or Fluent Forms).
