import json
import os

OUTPUT_DIR = r"C:\Users\Marketing Mindz 360\.gemini\antigravity\scratch\the-ranking-experts-elementor-templates"

# Read the full page JSON
full_page_path = os.path.join(OUTPUT_DIR, "11-the-ranking-experts-full-page.json")
with open(full_page_path, "r", encoding="utf-8") as f:
    data = json.load(f)

html_pieces = []
for sec in data["content"]:
    col = sec["elements"][0]
    for widget in col["elements"]:
        if widget.get("widgetType") == "html":
            html_pieces.append(widget["settings"]["html"])

full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>The Ranking Experts | Elite Digital Marketing Agency</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
  <style>
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body {{
      background-color: #07090E;
      color: #94A3B8;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      overflow-x: hidden;
      line-height: 1.5;
    }}
    a {{
      color: inherit;
    }}
    section {{
      padding: 80px 24px;
      position: relative;
    }}
    @media (max-width: 768px) {{
      section {{
        padding: 50px 16px;
      }}
      .tre-desktop-nav {{
        display: none !important;
      }}
      .tre-header-wrapper {{
        padding: 12px 18px !important;
      }}
    }}
  </style>
</head>
<body>
""" + "\n<section>".join([""] + html_pieces) + """
</body>
</html>
"""

with open(os.path.join(OUTPUT_DIR, "preview.html"), "w", encoding="utf-8") as f:
    f.write(full_html)

print("Generated preview.html successfully!")
